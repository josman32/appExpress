const data = [
    {
        fullName: "Jose Gonzalez",
        email: "jg@gmail.com",
        password: "123"
    }
];


module.exports = { data }
